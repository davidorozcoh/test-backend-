import json
from jsonschema import validate, ValidationError
from behave import given, when, then
import pytest

file_path = "data.json"

expected_json_schema = {
    "type": "array",
    "items": {
        "type": "object",
        "properties": {
            "identificación": {"type": "integer"},
            "nombre": {"type": "string"},
            "dirección": {"type": "string"},
            "código postal": {"type": "string"},
            "país": {"type": "string"},
            "número de empleados": {"type": "integer"},
            "industria": {"type": "string"},
            "capitalización de mercado": {"type": "integer"},
            "dominio": {"type": "string"},
            "logotipo": {"type": "string", "format": "uri"},
            "ceoName": {"type": "string"},
            "nombredelceo": {"type": "string"},
            "nombredeldirector": {"type": "string"},
            "nombre del director ejecutivo": {"type": "string"}
        },
        "required": [
            "identificación", "nombre", "dirección", "código postal",
            "país", "número de empleados", "industria",
            "capitalización de mercado", "dominio", "logotipo"
        ]
    }
}

@given('I have the JSON file "{filename}"')
def step_given_json_file(context, filename):
    with open(filename, 'r', encoding='utf-8') as f:
        context.response_json = json.load(f)

@when('I validate the JSON against the expected schema')
def step_when_validate_json(context):
    try:
        validate(instance=context.response_json, schema=expected_json_schema)
        context.validation_result = "JSON structure is correct and matches the schema."
    except ValidationError as e:
        context.validation_result = f"ERROR: Response does not match expected JSON schema. Details: {e.message}"
        pytest.fail(f"Response does not match expected JSON schema: {e.message}")

@then('I should see "{expected_message}"')
def step_then_validate_message(context, expected_message):
    assert expected_message in context.validation_result
